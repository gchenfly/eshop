<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubCategoryImage extends Model
{
    //
}
