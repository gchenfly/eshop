<?php

define('TEAM','team');

define('MESSAGE' , 'message');

?>